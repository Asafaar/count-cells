# Dog_Cat_Segmentation > 2025-01-09 6:56pm
https://universe.roboflow.com/myworkspace-p7gpw/dog_cat_segmentation-btyfb

Provided by a Roboflow user
License: CC BY 4.0

